function plot_uncertain(G_ic,s)
%plot of nominal system and sampled uncertain system
%G_ic --->uncertain function
%s --->number of samples
w = logspace(2,5,500);                                                           
G_ic_sampled = usample(G_ic,s);                                             %generate sampled functions
bode(G_ic.NominalValue,'r-',G_ic_sampled ,'b--',w), grid                    %plot
title('Bode plot of the uncertain plant')
legend('Nominal system','Random samples')
end

