function compute_response(Guy_ic,Gty_icm,K1,K2,K3,name)
    figure
    set(gcf,'Color','white');
    strA = 'closed loop responsefrom r to y using ';
    strB = 'closed loop responsefrom d to y using ';
    strnA = strcat(strA,name);
    strnB = strcat(strB,name);
    Lcl_nom_1 =K1*Guy_ic;                                                      % nominal open loop transfer function from r to y
    Scl_nom_1=(1+K1*Guy_ic)^-1;                                               % nominal sensibility function(transfer function from r to PES)
    Sd2PES_cl_nom_1=-0.0005*Gty_icm*Scl_nom_1;                                 % nominal tf from disturbance( 0.0005Nm amplitude step) to PES
    Tcl_nom_1=1-Scl_nom_1-1;                                                     % nominal complementary sensibility function(tf from r to y)
    Su_cl_nom_1=Guy_ic*Scl_nom_1;                                              % nominal control sensibility function(from r to u)
    Sud_cl_nom_1 =0.0005*K1*Scl_nom_1-1*Gty_icm;                                   % nominal transfer function from disturbance(0.0005Nm amplitude step) to u

    set(gcf,'Color','white');
    Lcl_nom_2 =K2*Guy_ic;                                                      % nominal open loop transfer function from r to y
    Scl_nom_2=(1+K2*Guy_ic)^-1;                                               % nominal sensibility function(transfer function from r to PES)
    Sd2PES_cl_nom_2=-0.0005*Gty_icm*Scl_nom_2;                                 % nominal tf from disturbance( 0.0005Nm amplitude step) to PES
    Tcl_nom_2=1-Scl_nom_2-1;                                                     % nominal complementary sensibility function(tf from r to y)
    Su_cl_nom_2=Guy_ic*Scl_nom_2;                                              % nominal control sensibility function(from r to u)
    Sud_cl_nom_2 =0.0005*K2*Scl_nom_2-1*Gty_icm;                                   % nominal transfer function from disturbance(0.0005Nm amplitude step) to u
    set(gcf,'Color','white');
    Lcl_nom_3 =K3*Guy_ic;                                                      % nominal open loop transfer function from r to y
    Scl_nom_3=(1+K3*Guy_ic)^-1;                                               % nominal sensibility function(transfer function from r to PES)
    Sd2PES_cl_nom_3=-0.0005*Gty_icm*Scl_nom_3;                                 % nominal tf from disturbance( 0.0005Nm amplitude step) to PES
    Tcl_nom_3=1-Scl_nom_3-1;                                                     % nominal complementary sensibility function(tf from r to y)
    Su_cl_nom_3=Guy_ic*Scl_nom_3;                                              % nominal control sensibility function(from r to u)
    Sud_cl_nom_3 =0.0005*K3*Scl_nom_3-1*Gty_icm;                                   % nominal transfer function from disturbance(0.0005Nm amplitude step) to u
    
    str0 = name ;
      
    s1 = strcat(str0," 1")
    s2 = strcat(str0," 2")
    s3 = strcat(str0," 3")
    
    
    subplot(1,2,1)
    step(Scl_nom_1,'r',Scl_nom_2,'g',Scl_nom_3,'b')
    legend(s1,s2,s3)
    set(gcf,'Color','white');
    title(strnA)
    subplot(1,2,2)
    step(Sd2PES_cl_nom_1,'r',Sd2PES_cl_nom_2,'g',Sd2PES_cl_nom_3,'b')
    legend(s1,s2,s3)
    set(gcf,'Color','white');
    title(strnB)
end

