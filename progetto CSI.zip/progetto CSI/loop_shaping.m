function [K,cl] = loop_shaping(G,W)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% compute the loop shaping controller
[K_0,cl,gam,info] = ncfsyn(G(1,2).Nom,W);
emax = info.emax;
disp(['The nugap robustness emax = ' num2str(emax)]);
%
% frequency responses of the plant and shaped plant
Gs = info.Gs;
w = logspace(-1,5,400);
figure()
bodemag(G(1,2).Nom,'b-',Gs,'r-',w), grid
title('Frequency responses of the plant and shaped plant')
legend('Original plant','Shaped plant')
%
% obtain the negative feedback controller
K_lsh = -K_0;
K = K_lsh;
end

