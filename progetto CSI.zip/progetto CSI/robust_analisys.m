function robust_analisys(sys_ic,K,c_name)
    % Robustness analysis of the Hard Disk Drive Servo System
    %
    disp("----------------------------------------------")
    disp(c_name)
    disp("----------------------------------------------")
    figure()
    ubs = ' upper bound';
    lbs = ' lower bound';
    nus = strcat(c_name,ubs);
    nls = strcat(c_name,lbs);
    clp_ic = lft(sys_ic,K,1,1);
    w = logspace(3,5,100);
    clp_g = ufrd(clp_ic,w);
    
    %
    % robust stability analysis
    opt = robopt('Display','on');
    [stabmarg,destabu,report,info] = robuststab(clp_g,opt);
    disp(destabu)
    disp(stabmarg)
    disp(report)
    semilogx(info.MussvBnds(1,1),'r-',info.MussvBnds(1,2),'b-')
    grid
    title('Robust stability')
    xlabel('Frequency (rad/s)')
    ylabel(c_name)
    legend(nus,nls)
    %
    figure()
    % nominal performance
    w = logspace(2,5,100);
    sv = sigma(clp_ic.Nominal,w);
    sys_frd = frd(sv(1,:),w);
    semilogx(sys_frd,'r-')
    grid
    title('Nominal performance')
    xlabel('Frequency (rad/s)')
    %
    figure()
    % robust performance
    w = logspace(3,5,100);
    opt = robopt('Display','on');
    [perfmarg,perfmargunc,report,info] = robustperf(clp_g,opt);
    disp(perfmargunc)
    disp(perfmarg)
    disp(report)
    semilogx(info.MussvBnds(1,1),'r-',info.MussvBnds(1,2),'b-')
    grid
    title('Robust performance')
    xlabel('Frequency (rad/s)')
    ylabel(c_name)
    legend(nus,nls)
end

