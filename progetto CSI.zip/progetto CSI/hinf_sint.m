function [K_hinf,clp_hin,gfin] = hinf_sint(ic_system,nmeas,ncon,gmin,gmax,tol)
    % H_infinity design for the Disk Drive System
    hin_ic = ic_system.Nom;
    opts = hinfsynOptions('AbsTol',tol);
    [~,~,gopt] = hinfsyn(hin_ic,nmeas,ncon,[gmin,gmax],opts);                   %first search
    gmin = 1.1*gopt;                                                            %update near first gopt
    disp(gmin)
    disp(gmax)
    [K_hinf,clp_hin,gfin] = hinfsyn(hin_ic,nmeas,ncon,[gmin,gmax],opts);        %search again 
    disp(gmin)
    disp(gmax)
end

