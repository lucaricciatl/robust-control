
G = define_system_HDD();                                                   %define uncertain system

G_nom = G.NominalValue;                                                    %define nominal system


set(gcf,'Color','white');

Gty_ol = G(1,1);                                                           %uncertain transfer function from td to y
Guy_ol = G(1,2);                                                           %uncertain transfer function from u to y


figure(1)
plot_uncertain(Guy_ol,50)                                                  %plot open loop uncertain system

%%
hold on

[Wm1,Wn1,Wp1,Wu1] = create_weights(1);
[Wm2,Wn2,Wp2,Wu2] = create_weights(2);
[Wm3,Wn3,Wp3,Wu3] = create_weights(3);
 
figure(2)
set(gcf,'Color','white');
w = logspace(-1,5,500);
bodemag(1/Wp1,'r',1/Wp2,'g',1/Wp3,'b',w), grid
legend('1/Wp1','1/Wp2','1/Wp3')
title('Inverse Performance Weighting Function')

figure(3)
set(gcf,'Color','white');
w = logspace(-1,6,100);
bodemag(Wu1,'r',Wu2,'g',Wu3,'b',w), grid
legend('Wu1','Wu2','Wu3')
title('Control Weighting Function')

figure(4)
set(gcf,'Color','white');
w = logspace(0,4,100);
bodemag(Wn1,'r',Wn2,'g',Wn3,'b',w), grid
legend('Wn1','Wn2','Wn3')
title('Noise shaping filter frequency response')



%open-loop connection 
systemnames = ' G Wn ';
inputvar = '[ ref; dist; noise; control ]';
outputvar = '[ G(1); control; ref-G(1)-Wn ]';
input_to_G = '[ dist; control ]';
input_to_Wn = '[ noise ]';
cleanupsysic = 'yes';
sim_ic = sysic; 




%%

[Wm,Wn,Wp,Wu] = create_weights(1);
Wm = Wm;
Wn = Wn;
Wp = Wp;
Wu = Wu;
%open-loop connection with the weighting function
systemnames = ' G Wm Wn Wp Wu ';
inputvar = '[ r; d; n; u ]';                                               %w = [ref,dist,noise] u =[control]
outputvar = '[ Wp; Wu; r-G(1)-Wn ]';
input_to_G = '[ d; u ]';
input_to_Wm = '[ r ]';
input_to_Wn = '[ n ]';
input_to_Wp = '[ G(1) - Wm ]';
input_to_Wu = '[ u ]';
cleanupsysic = 'yes';                                                      %clear input in workspace after sysic is created
sis_ic_1 = sysic;                                                             

[Wm,Wn,Wp,Wu] = create_weights(2);
Wm = Wm;
Wn = Wn;
Wp = Wp;
Wu = Wu;
systemnames = ' G Wm Wn Wp Wu ';
inputvar = '[ r; d; n; u ]';                                               %w = [ref,dist,noise] u =[control]
outputvar = '[ Wp; Wu; r-G(1)-Wn ]';
input_to_G = '[ d; u ]';
input_to_Wm = '[ r ]';
input_to_Wn = '[ n ]';
input_to_Wp = '[ G(1) - Wm ]';
input_to_Wu = '[ u ]';
cleanupsysic = 'yes';                                                      %clear input in workspace after sysic is created
sis_ic_2 = sysic;

[Wm,Wn,Wp,Wu] = create_weights(3);
Wm = Wm;
Wn = Wn;
Wp = Wp;
Wu = Wu;
systemnames = ' G Wm Wn Wp Wu ';
inputvar = '[ r; d; n; u ]';                                               %w = [ref,dist,noise] u =[control]
outputvar = '[ Wp; Wu; r-G(1)-Wn ]';
input_to_G = '[ d; u ]';
input_to_Wm = '[ r ]';
input_to_Wn = '[ n ]';
input_to_Wp = '[ G(1) - Wm ]';
input_to_Wu = '[ u ]';
cleanupsysic = 'yes';                                                      %clear input in workspace after sysic is created
sis_ic_3 = sysic;    

%%
%loop shaping
nuW1 = [0.05 1];
dnW1 = [1 0];
gainW1 = 4;

W1 = gainW1*tf(nuW1,dnW1);
[K_ls,cl_ls] = loop_shaping(G,W1);

figure
bode(K_ls,'r-'), grid
title('Controller loop shaping')
set(gcf,'Color','white');
robust_analisys(sis_ic_2,K_ls,"loop shaping")

figure
cl_ltr = (1+K_ls*Guy_ol)^-1; 
set(gcf,'Color','white');
stepplot(cl_ltr)

compute_sys_response(sim_ic,K_ls)

%%
%design HINF

figure
bode(sis_ic_1,'r-',sis_ic_2,'g-',sis_ic_3,'b-'), grid
title('systems')
legend('sys1','sys2','sys3')

ninf_1 = hinfnorm(tf(sis_ic_1),0.001);
ninf_2 = hinfnorm(tf(sis_ic_2),0.001);
ninf_3 = hinfnorm(tf(sis_ic_3),0.001);
disp(ninf_1)
disp(ninf_2)
disp(ninf_3)
nmeas=1;                                                                   %numero di segnali in y 
ncon = 1;                                                                  %numero di segnali in u
gmin=0;                                                                    %valore min di partenza
gmax=10;                                                                   %valore max di partenza
tol = 0.001;                                                               %tolleranza di ricerca gamma
[K_hinf_1,clp_hin_1,gfin_1] = hinf_sint(sis_ic_1,nmeas,ncon,gmin,gmax,tol);  %sintesi controllore h_inf
[K_hinf_2,clp_hin_2,gfin_2] = hinf_sint(sis_ic_2,nmeas,ncon,gmin,gmax,tol);  %sintesi controllore h_inf
[K_hinf_3,clp_hin_3,gfin_3] = hinf_sint(sis_ic_3,nmeas,ncon,gmin,gmax,tol);  %sintesi controllore h_inf
disp(gfin_1)
disp(gfin_2)
disp(gfin_3)
%robust_analisys(sis_ic_1,K_hinf_1,"hinf 1")
robust_analisys(sis_ic_2,K_hinf_2,"hinf 2")
%robust_analisys(sis_ic_3,K_hinf_3,"hinf 3")
disp(' ')
disp(' ')
disp('Closed-loop poles')
get(K_hinf_1)
sp = pole(clp_hin_1);
omega = logspace(-2,6,100);

sigma(clp_hin_1,'r',clp_hin_2,'g',clp_hin_3,'b',omega)
gamma_line = db(gfin_2)*ones(1,length(omega));
plot(omega,gamma_line,"m")
set(gcf,'Color','white');
title('Singular Value Plot of clp')
xlabel('Frequency (rad/sec)')
ylabel('Magnitude')
set(gcf,'Color','white');

figure
hold on
sigma(clp_hin_2,'g',omega)
gamma_line = db(gfin_2)*ones(1,length(omega));
plot(omega,gamma_line,"m")
hold off


compute_response(Guy_ol.NominalValue,Gty_ol.NominalValue,K_hinf_1,K_hinf_2,K_hinf_3," hinf ")


Lcl_nom_h =K_hinf_2*Guy_ol.Nom;                                                      % nominal open loop transfer function from r to y
Scl_nom_h =(1+K_hinf_2*Guy_ol.Nom)^-1;                                               % nominal sensibility function(transfer function from r to PES)

figure
bode(K_hinf_1,'r',K_hinf_2,'g',K_hinf_3,'b'), grid
set(gcf,'Color','white');
title('Controller hinf Bode plots')
legend('hinf_1','hinf_2','hinf_3')

%%
%design MU
nmeas = 1;
ncont = 1;

[K_mu_1,CL_mu_1] = mu_syn_hdd(sis_ic_1,nmeas,ncont);               %sintesi controllore mu
%robust_analisys(sis_ic_1,K_mu_1,"mu1")                                          %effettua la analisi i robustezza del controllore mu
ninf = hinfnorm(tf(CL_mu_1),0.001);
disp(ninf)
step(lft(sis_ic_1.Nom,K_mu_1))
Scl_nom_1 = (1+K_mu_1*Guy_ol.NominalValue)^-1;


[K_mu_2,CL_mu_2] = mu_syn_hdd(sis_ic_2,nmeas,ncont);               %sintesi controllore mu
%robust_analisys(sis_ic_2,K_mu_2,"mu2")                                          %effettua la analisi i robustezza del controllore mu
ninf = hinfnorm(tf(CL_mu_2),0.001);
disp(ninf)
step(lft(sis_ic_2.Nom,K_mu_2))
Scl_nom_2 = (1+K_mu_2*Guy_ol.NominalValue)^-1;


[K_mu_3,CL_mu_3] = mu_syn_hdd(sis_ic_3,nmeas,ncont);               %sintesi controllore mu
%robust_analisys(sis_ic_3,K_mu_3,"mu3")                                          %effettua la analisi i robustezza del controllore mu
ninf = hinfnorm(tf(CL_mu_3),0.001);
disp(ninf)
step(lft(sis_ic_3.Nom,K_mu_3))
Scl_nom_3 = (1+K_mu_3*Guy_ol.NominalValue)^-1;

figure
step(Scl_nom_1,'r',Scl_nom_2,'g',Scl_nom_3,'b')

red_mu_1 = reduce(K_mu_1,13);
red_mu_2 = reduce(K_mu_2,16);
red_mu_3 = reduce(K_mu_3,13);

rid_nom_1 = (1+red_mu_1*Guy_ol.NominalValue)^-1;
rid_nom_2 = (1+red_mu_2*Guy_ol.NominalValue)^-1;
rid_nom_3 = (1+red_mu_3*Guy_ol.NominalValue)^-1;

rid_nom_1d = (1+red_mu_1*Gty_ol.NominalValue)^-1;
rid_nom_2d = (1+red_mu_2*Gty_ol.NominalValue)^-1;
rid_nom_3d = (1+red_mu_3*Gty_ol.NominalValue)^-1;

figure
bode(K_mu_1,'r-',red_mu_1,'b-'), grid
set(gcf,'Color','white');
title('Controller mu Bode plots 1')
legend('Full order controller', ...
       'Reduced-order (n = 13) controller')
figure
bode(K_mu_2,'r-',red_mu_2,'b-'), grid
set(gcf,'Color','white');
title('Controller mu Bode plots 2')
legend('Full order controller', ...
       'Reduced-order (n = 13) controller')
figure
bode(K_mu_3,'r-',red_mu_3,'b-'), grid
set(gcf,'Color','white');
title('Controller mu Bode plots 3')
legend('Full order controller', ...
       'Reduced-order (n = 13) controller')

figure
bode(Scl_nom_3,'g',(1+red_mu_2*Guy_ol.NominalValue)^-1,'r'), grid
set(gcf,'Color','white');
title('sistema a ciclo chiuso usando il set 2')
legend('Full order controller', ...
       'Reduced-order (n = 13) controller')

compute_response(Guy_ol.NominalValue,Gty_ol.NominalValue,red_mu_1,red_mu_2,red_mu_3," mu ")

compute_sys_response(sim_ic,K_mu_2)

% %%
% %design LQR
% % [A,B,C,D] = ssdata(G_nom);
% % n = length(A);
% % Q = C'*C;
% % rho = 0.1;
% % R = rho;
% % V = 1;
% % Klqg = lqr(G_nom,Q,R);                                                     % computes LQR controller 
% % Scl_nom = (1+Klqg*Guy_ol)^-1;
% % step(Scl_nom)
% % 
% %   
% 
%%
%design LQG/LTR
Guy_ol_nom = Guy_ol.Nominalvalue;
[A,B,C,D]=ssdata(Guy_ol_nom);
n=length(A);
Q=eye(n);
W=eye(n);
V=1;
Qweight=blkdiag(Q,1);
Qnoise=blkdiag(W,V);

Klqg = lqg(Guy_ol_nom,Qweight,Qnoise,1,'1dof');                                  %computes LQG controller 
w=logspace(2,5,500);

Xi = B*B'; Th = 200;                                                       %noise weighting
q  = 1e5;                                                                  %recovery gain for Q:being a RHP zero at about 10^6 rad/s                                                                          %the recover can be done only till frequencies below this limit;        
Q = C'*C; 
R = 200;                                                                   %initial control weight 
XiTh = diagmx(Xi,Th);           
[Kf] = lqrc(A',C',XiTh);                                                   %Solve Kalman filter gain
Kf = Kf';                                                                  %using duality with LQR  
[Kltr,SVL,W1] = ltrsyn(Guy_ol_nom,Kf,Q,R,q,w,'OUTPUT');                        %computes LTR(on output) 
                                                             %controller and plot nyquist plot of L2(s)=Gunom*Kltr
                                                                           %nyquist(A,Kf,C,0,1,w)   % nyquist plot of L4(s)= C*(sI-A)^-1*Kf
                                                                           
robust_analisys(sis_ic_2,Kltr,"lqg/ltr")

figure
strA = 'closed loop responsefrom r to y using ltr';
strB = 'closed loop responsefrom d to y using ltr';

Lcl_nom_1 =Kltr*Guy_ol_nom;                                                      % nominal open loop transfer function from r to y
Scl_nom_1=(1+Kltr*Guy_ol_nom)^-1;                                               % nominal sensibility function(transfer function from r to PES)
Sd2PES_cl_nom_1=-0.0005*Gty_ol.NominalValue*Scl_nom_1;                                 % nominal tf from disturbance( 0.0005Nm amplitude step) to PES
Tcl_nom_1=1-Scl_nom_1-1;                                                     % nominal complementary sensibility function(tf from r to y)
Su_cl_nom_1=Guy_ol_nom*Scl_nom_1;                                              % nominal control sensibility function(from r to u)
Sud_cl_nom_1 =0.0005*Kltr*Scl_nom_1-1*Gty_ol.NominalValue;                                   % nominal transfer function from disturbance(0.0005Nm amplitude step) to u

subplot(1,2,1)
step(Scl_nom_1,'r')
title(strA)
subplot(1,2,2)
step(Sd2PES_cl_nom_1,'r')
title(strB)

compute_response(Guy_ol.NominalValue,Gty_ol.NominalValue,Kltr,Kltr,Kltr," ltr ")

%compute_sys_response(sim_ic,Kltr)

%%
%confronto finale
figure
m(K_ls,"r",red_mu_2,"g",K_hinf_2,'b',Kltr,'m')
title('confronto tra diagrammi di bode dei controllori')
legend('loop_shaping','mu controller','Hinf controller','LTR controller')
figure
bode((1+K_ls*Guy_ol.Nom)^-1,"r",(1+red_mu_2*Guy_ol.Nom)^-1,"g",(1+K_hinf_2*Guy_ol.Nom)^-1,'b',(1+Kltr*Guy_ol.Nom)^-1,'m')
title('diagramam di bode del sistema ad anello chiuso')
legend('loop_shaping','mu controller','Hinf controller','LTR controller')

figure
margin((1+K_ls*Guy_ol.Nom)^-1)
figure
margin((1+red_mu_2*Guy_ol.Nom)^-1)
figure
margin((1+K_hinf_2*Guy_ol.Nom)^-1)
figure
margin((1+Kltr*Guy_ol.Nom)^-1)

figure
stepplot((1+K_ls*Guy_ol.Nom)^-1,"r",(1+K_mu_2*Guy_ol.Nom)^-1,"g",(1+K_hinf_2*Guy_ol.Nom)^-1,'b',(1+Kltr*Guy_ol.Nom)^-1,'m')
title('risposta al gradino')
legend('loop_shaping','mu controller','Hinf controller','LTR controller')
figure
subplot(2,2,4);
step((1+K_ls*Guy_ol)^-1,"r");
legend('loop_shaping')
subplot(2,2,3);
step((1+red_mu_2*Guy_ol)^-1,"g");
legend('mu controller')
subplot(2,2,2);
step((1+K_hinf_2*Guy_ol)^-1,'b');
legend('Hinf controller')
subplot(2,2,1);
step((1+Kltr*Guy_ol)^-1,'m');
legend('LTR controller')

figure
stepplot((1+K_ls*Guy_ol.Nom)^-1,"r",(1+K_mu_2*Guy_ol.Nom)^-1,"g",(1+K_hinf_2*Guy_ol.Nom)^-1,'b',(1+Kltr*Guy_ol.Nom)^-1,'m')
title('risposta al gradino')
legend('loop_shaping','mu controller','Hinf controller','LTR controller')

figure
step((1+red_mu_2*Guy_ol)^-1,"g",(1+Kltr*Guy_ol)^-1,'m')
title('risposta al gradino')

legend('mu controller','LTR controller')

compute_response(Guy_ol.NominalValue,Gty_ol.NominalValue,Kltr,red_mu_2,K_hinf_2,'')